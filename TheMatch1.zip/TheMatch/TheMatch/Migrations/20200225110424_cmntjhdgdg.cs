﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMatch.Migrations
{
    public partial class cmntjhdgdg : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Mail = table.Column<long>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Age = table.Column<int>(nullable: false),
                    Gender = table.Column<string>(nullable: true),
                    Bio = table.Column<string>(nullable: true),
                    Sexual_orientation = table.Column<string>(nullable: true),
                    ImageUrl = table.Column<string>(nullable: true),
                    ImageThumbnailUrl = table.Column<string>(nullable: true),
                    CategoryId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName" },
                values: new object[,]
                {
                    { 1, "Male" },
                    { 2, "Female" },
                    { 3, "Both" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Age", "Bio", "CategoryId", "Gender", "ImageThumbnailUrl", "ImageUrl", "Mail", "Name", "Sexual_orientation" },
                values: new object[,]
                {
                    { 1L, 22, "Hey There!", null, "Male", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", 0L, "abc def", null },
                    { 2L, 35, "I am a big foodie!", null, "Female", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", 0L, "ghi jkl", null },
                    { 3L, 28, "I love books!", null, "Female", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small", "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", 0L, "mno pqr", null },
                    { 4L, 30, "I love adventures!", null, "Male", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg", "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", 0L, "stu vwx", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Users_CategoryId",
                table: "Users",
                column: "CategoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
