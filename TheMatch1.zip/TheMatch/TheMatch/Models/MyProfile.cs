﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class MyProfile
    {
        public long M_Id { get; set; }
        public long M_Mail { get; set; }
        public string M_Name { get; set; }
        public int M_Age { get; set; }
        public string M_Gender { get; set; }
        public string M_Bio { get; set; }
        public string M_Sexual_orientation { get; set; }
        public string M_ImageUrl { get; set; }
        public string M_ImageThumbnailUrl { get; set; }
    }
}
