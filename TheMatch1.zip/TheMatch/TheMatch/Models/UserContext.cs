﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<MyProfile> MyProfiles { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 1, CategoryName = "Male" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 2, CategoryName = "Female" });
            modelBuilder.Entity<Category>().HasData(new Category { CategoryId = 3, CategoryName = "Both" });

            modelBuilder.Entity<User>().HasData(new User
            {
                Id = 1,
                Name = "abc def",
                Age = 22,
                Gender = "Male",
                Bio = "Hey There!",
                ImageUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg",
                ImageThumbnailUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg"

            });

            modelBuilder.Entity<User>().HasData(new User
            {
                Id = 2,
                Name = "ghi jkl",
                Age = 35,
                Gender = "Female",
                Bio = "I am a big foodie!",
                ImageUrl = "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
                ImageThumbnailUrl = "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small"
            });

            modelBuilder.Entity<User>().HasData(new User
            {
                Id = 3,
                Name = "mno pqr",
                Age = 28,
                Gender = "Female",
                Bio = "I love books!",
                ImageUrl = "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80",
                ImageThumbnailUrl = "https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small"
            });

            modelBuilder.Entity<User>().HasData(new User
            {
                Id = 4,
                Name = "stu vwx",
                Age = 30,
                Gender = "Male",
                Bio = "I love adventures!",
                ImageUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg",
                ImageThumbnailUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg"
            });
            

            //myprofile
            modelBuilder.Entity<MyProfile>().HasData(new MyProfile
            {
                M_Id = 1,
                M_Name = "Me",
                M_Age = 22,
                M_Gender = "Female",
                M_Bio = "Hi!",
                M_ImageUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg",
                M_ImageThumbnailUrl = "https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg"

            });

        }  
    }
}

